<?php 
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>MobiMed- Ajouter Patient </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <!-----Angular JS------->

<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular-route.js"></script>

</head>
<body>


<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!--<a class="navbar-brand" href="mobimed.php">MobiMed</a>-->
  <img src='mobimed.jpg' alt='mobimed' width='40px'>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="Mobimed.php"> MobiMed<span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Gestion rendez Vous
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="rdv.php">Ajouter un Rendez Vous</a>
        
               
          </div>
          <!---------------->

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Gestion Patient
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="AjouterPatient.php">Ajouter Un Patient </a>
              
              
            
            </div>

          <!------------------>
      <li class="nav-item">
        <a class="nav-link" href="#">Gestion Comptabilité</a>
      </li>
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="index.html" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Gestion Maladie
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="consultation.php">Ajouter nouvelle Consultation</a>
            <a class="dropdown-item" href="ordanance.php">Gerer Ordonanacement</a>
            <a class="dropdown-item" href="certificatmedicale.php">Gerer Certificat medicale</a>
        </div>
      </li>
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src='avatar.png' width='20px' alt='avatar'><?php echo $_SESSION['user']?>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="#">Ajouter Nouvelle Medecin (En cours ...)</a>
            <a class="dropdown-item" href="#">Ajouter Nouvelle Secretaire (En Cours ...)</a>
            <a class="dropdown-item" href="#">changer photo de profil(En cours ....)</a>
            
          </div>
          
        
    </ul>
  </div>
</nav>
<!----------------------------------->


<label style='color:blue' onclick="window.location.href='mobimed.php'">Acceuil</label>/Ajouter Un Patient 
<div class="jumbotron text-center">
  <h1>MobiMed</h1>
  <p>Système de gestion de cabinet Medicale </p> 
</div>
  <h3>Ajouter Patient </h3>
  <form method="POST">
    <table class='table table-darked'>
    <tr>
    <td>CIN patient<input type='text'   class='form-control'size='8'name='CIN_Patient'> </td>
    <td> Nom patient <input type='text' name='name_patient'  class="form-control" id='name_patient' > </td>

    <td> Prenom patient <input type='text' name='Prenom_patient'  class="form-control" id='Prenom_patient' > </td>
    <td>Sexe 
    <table>
    <tr>
    <td><input type='radio' name='sexe' value='M'>Masculin</td>
    <td><input type='radio' name='sexe' value='F'>Femenin</td>

    </table>
    </tr>
    <tr>
    </td>
    <td>
    Num Telephone patient <input type='text' class='form-control' name='num_tel_pat'> 
    </td>
    <td> Adresse patient <input type='text' name='adresse_patient'  class="form-control" id='Adresse_patient' > </td>

    <td> Date Naissennce patient (aaa-mm-jj)<input type='text' name='Date_naiss_patient'  class="form-control" id='Date_naiss_patient' > </td>
    <td> Code APCI <input type='text' name='Code_APCI'  class="form-control" id='Code_APCI' > </td>
    
    </tr>
        <tr>
        <td><input type='submit' name="BTNEnvoyer" class='btn-success' value='Ajouter patient'></td>
        <td><input type='reset' name='BTNReset' class='btn-warning' value='Annuler'></td>
        </tr>
    </table>
  </form>
</body>
</html>
<?php 

require "Model.php";

if(isset($_POST['BTNEnvoyer']))
Patient::Ajouter($_SESSION['user'],$_POST['CIN_Patient'],$_POST['name_patient'],$_POST['Prenom_patient'],$_POST['Date_naiss_patient'],$_POST['sexe'],$_POST['adresse_patient'],$_POST['num_tel_pat'],$_POST['Code_APCI']);
echo "<hr>";
//$date_rdv , $heure_rdv , $nombre_jours , $num_patient
//DV::Ajouter("Date RDV : 2020-12-30","heure 15:00","periode : 5 jours",1)
?>
<style>
    nav {
        background-color: #2c3e50;
        
    }
    nav>a {
        width: 40px;
        color:azure;
        text-decoration:none;
        padding:20px;
    
    }
   
</style>