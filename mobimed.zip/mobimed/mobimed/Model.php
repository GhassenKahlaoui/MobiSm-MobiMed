<?php 
error_reporting(E_ALL|| E_NOTICE);
require "config.php" ; 
/*******************Model version 0.1****************************** */
/*******************developper par kahlaoui mohamed Ghassen Email : ghassenkahlaoui@gmail.com **************************** */
// cette classe réprésente la tableau consultation de chaque Patient ////////////
class Admin {

    public static function LoginAdmin($cin,$mot2pass)  {
        if($cin =="MobiMed" && $mot2pass =="MobiMed")
        return 1 ; 
        else 
        return -1 ; 
    }
}
class Medecin  {
    public $cin,$nom,$prenom,$specialite,$mot2pass ; 

    public static function AjouterMedecin($cin,$nom,$prenom,$specialite,$mot2pass) {


            if(Connexion::getInstance())
            if(mysqli_num_rows(Connexion::query("select * from Medecin where cin = '$cin'"))>0)
            echo "<h1 style='box-shadow: 20px 20px 30px #34495e ;background-color:#e74c3c;'>Medecin est deja existe est ce que tu peut le modifier ? <a href='modifierMedcin?cin=$cin'>Modifier</a></h1>";
        

            if(Connexion::getInstance())
            if(mysqli_num_rows(Connexion::query("select * from Medecin where cin = '$cin'"))==0)
                 {
                    echo "<h1 style='box-shadow: 20px 20px 30px #34495e ;background-color:#1abc9c;' >Ajouter  Meddecin Avec sucess</h1>" ;
            
                    Connexion::query("insert into Medecin Values('$cin','$nom','$prenom','$specialite','$mot2pass' )");
                    
                 }
             

            

        }

        public function getPatientConsultation($cinMEdecin) {
            $listPatient = array() ; 
            $query_patient_consultation = "select * from medecin_patient where Cin_medcin =$cinMEdecin "; 
            if(Connexion::getInstance())
            $queryPatient = Connexion::query($query_patient_consultation);
            while($row_patient = mysqli_fetch_row($queryPatient))
            array_push($listPatient,$row_patient[2]);
            echo "<h3 style='background-color:#1abc9c;padding-left:40%;box-shadow:20px 20px 30px #34495e;' >Liste des Consultation </h3>";

            echo "<hr>"; 
            echo "<table class='table table-darked'><tr>";   
            
            for($count =0;$count<count($listPatient);$count++) {
                $queryConsultation =  "select * from Consultation where num_patient=".$listPatient[$count];
                if(Connexion::getInstance())
                $execquery = Connexion::query($queryConsultation);
                if($execquery)
                if(mysqli_num_rows($execquery)>0) {
                while($row_consultation = mysqli_fetch_row($execquery)) {
                echo "<td>";
                echo "
                
                <div class='card' style='width:400px'>
      <img class='card-img-top' style='10px;' src='patientDocteur.png' alt='Card image'>
      <div class='card-body'>
        <h4 style='background-color:#1abc9c;' class='card-title'>Cin Du patient : ".$row_consultation[3]."</h4>
        <p class='card-text'>
        <label>Date de Consultation</label> $row_consultation[1] <hr>
      <label>Consulation :</label> $row_consultation[2] 
        </p>
       </div>
    </div>
                
                
                </td><td>";
            }
            }
    
            echo "</tr>";
            echo "</table>";        
        } 
        if(mysqli_num_rows($execquery)==0) {
            echo "<h1 style='background-color:#e74c3c;color:azure;'> Opps tu pas aucune Consultation <img width='34px'src='sad.png'></h1>";
        }
        }    
        public static function getstat() {
             echo "<table class='table table-darked'>";   
            if(Connexion::getInstance())
            $result = Connexion::query("select Count(*) as total from Medecin");
            $data = mysqli_fetch_assoc($result);
            echo "<tr><td>";
            echo "
            
            <div class='card' style='width:400px'>
  <img class='card-img-top' src='Doctor.png' alt='Card image'>
  <div class='card-body'>
    <h4 class='card-title'>Nombre de Docteur : $data[total]</h4>
   </div>
</div>
            
            
            </td><td>";


            if(Connexion::getInstance())
            $result = Connexion::query("select Count(*) as total from Patient");
            $data = mysqli_fetch_assoc($result);
            if($data['total']>0) 
            $nb = $data['total'] ;
            else 
            $nb =0;;
            echo "
            
            <div class='card' style='width:400px'>
  <img class='card-img-top' src='Patient.png' alt='Card image'>
  <div class='card-body'>
    <h4 class='card-title'>Nombre de Patient : ".$nb  ."</h4>
   </div>
</div>
            
            
            </td></tr>";
            echo "</table>";
            ;
        }
        public static function logiMmedecin($cin,$motdepass)  {

            if(Connexion::getInstance())
            $search_medeicn = Connexion::query("select * from Medecin where CIN='$cin' and pass='$motdepass'");
            if(mysqli_num_rows($search_medeicn)>0)
             
                
                    return 1 ; 

                            else return -1;
        }
}
class Consultation {

        public $numConsultation, $dateConsultation , $daig_consultataion , $numpatient ; 

        public static function Ajouter($numConsultation, $dateConsultation , $daig_consultataion , $numpatient ) {
            if(Connexion::getInstance())
             {

             
            echo "<h1 style='box-shadow: 20px 20px 30px #34495e ;background-color:#1abc9c;' >Ajouter  Consultation Avec sucess</h1>" ;
            
            //echo $numConsultation ."-".$dateConsultation ."-". $daig_consultataion ."-". $numpatient ; 
            $query= "insert into Consultation Values('$numConsultation','$dateConsultation','$daig_consultataion','$numpatient')"; 
            Connexion::query($query) ; 
             }

        }
        public static function Modifier() {}

}


// cette classe réprésente la tableau Rnedz vous de chaque Patient ////////////

class RDV {
    public $date_rdv , $heure_rdv , $nombre_jours , $num_patient ; 
    public static function Ajouter($nb_rdv,$date_rdv , $heure_rdv , $nombre_jours , $num_patient) {

        if(Connexion::getInstance())
        {
        $query_search = "select * from RDV where date_rdv='$date_rdv' and heure_rdv='$heure_rdv'   "; 
        $exec = Connexion::query($query_search) ; 
        if(mysqli_num_rows($exec)>0) 
        echo "<h1 style='box-shadow: 20px 20px 30px #34495e ;background-color:#e74c3c;'>Date Rserver SVP choisir autre Date </h1>";
        
        
        if(mysqli_num_rows($exec)==0) {
          
            echo "<h1 style='box-shadow: 20px 20px 30px #34495e ;background-color:#1abc9c;' >Ajouter Avec sucess</h1>" ;
            
            $queru = "insert into RDV values($nb_rdv,'$date_rdv','$heure_rdv','$nombre_jours','$num_patient')";
            //echo $queru ; 
                    //echo Connexion::query($queru);
                        
                    
        }
    echo "<hr>";

    }
}
    public static function Affiche() {

    }
    public static function Modifier() {

    }

    public static function Supprimer() {

    }
}
// cette classe réprésente la tableau chaque Patient ////////////

class Patient {
    public $Allpatient = array();
    // les proprieté sont publique car quand on peut faire des webservice il faut que parametres sont publique n'est pas privé 
    public $num_patient , $Nom_patient, $Pren_pat , $date_naissence, $sexe_patient , $addree_patient,$code_paci, $Identifcateur_rendez_vous;
    public static function Ajouter($user,$num_patient , $Nom_patient, $Pren_pat , $date_naissence, $sexe_patient , $addree_patient,$num_tel_pat,$code_paci) {
        $query_insert_patient_medecin= "insert into medecin_patient  (Cin_medcin,Cin_Patient)Values ('$user','$num_patient')"; 
        if(Connexion::getInstance())
        if(Connexion::query($query_insert_patient_medecin))
      
        $query_search_q = "select * from patient where Num_pat='$num_patient'"; 
      if(Connexion::getInstance())
      if(mysqli_num_rows(Connexion::query($query_search_q))>0)
            echo "<h1 style='box-shadow: 20px 20px 30px #34495e ;background-color:red'>Patient existe</h1>" ; 
    
        if(Connexion::getInstance())
        if(mysqli_num_rows(Connexion::query($query_search_q))==0)
        $insert_quer = "insert into patient  values('$num_patient','$Nom_patient','$Pren_pat','$date_naissence','$sexe_patient','$addree_patient','$num_tel_pat',$code_paci)";
        if(Connexion::getInstance())
        if(Connexion::query($insert_quer))
        echo "<h1 style='background-color:#1abc9c'>Ajouter Avec succes</h1>" ; 
    

    
    
}

    public static function Modifier($idPatient) {
            if(Connexion::getInstance())
                echo "tu sur pour modifier ! " . $idPatient ; 

    }
    public function Archiver($idPatient) {
        // dans le monde informatique n'utilise pas supprimer mais arhiver car on peut le reutiser 

    }
}

?>