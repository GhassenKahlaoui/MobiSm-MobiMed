<?php 


require 'fpdf.php';
class MyPDF extends FPDF {
    
function  header() { 
      
    $this->SetFont('Arial','B',10); 
    $date = date("Y");
    $lastDate = (int)$date-1;
    //$this->Image("capture.png",0,0,0);
    //$this->Cell(110,5,'Republique Tunisienne ' ,0,0,'L') ;
    //$this->Ln();
    //$this->Cell(100,5,'Ministere de l\'enseignement superieur et de la Recherche' ,0,0,'L') ;
   
    //$this->Cell(290,5,'Direction Generale des etudes technologiques ' ,4,4,'L') ;
    //$this->Ln();
    //$this->Cell(450,5,'Institut Superieur des Etudes Technologiques de Jendouba' ,0,0,'L') ;
    //$this->Ln();
    $this->Cell(200,12,'ordonance Medicale '.   $date ,0,0,'C') ;
    $this->Ln();
    $this->SetFont('Times','B',12) ; 
    
    $this->Cell(150,20,'Coordonnees du cabinet medical .........................................................',0,0,'C');
    $this->Ln(10);
    //$this->Cell(20,5,'Ne le :'.$et->getDateNaissence(),0,0,'C'); 
    $this->SetFont('Times','',12); 
    $this->Cell(210,20,"Date du document  : ................................" ,0,0,'C'); 
    $this->cell(-250,30,"Informations relatives au patient :............................................",0,0,'C');
    $this->Ln(20);
    $this->Cell(0,40,"--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------",0,0,"C");
    $this->Ln(16);

    $this->Cell(0,40,"..........................................................................................................................................................................................................................................................................",0,0,"C");
    $this->Ln(16);

    $this->Cell(0,40,"..........................................................................................................................................................................................................................................................................",0,0,"C");
    $this->Ln(16);
    $this->Cell(200,40,"............................................................................................................................................................................",0,0,"C");
    $this->Ln(16);
    $this->Cell(300,40," .............................................................................................................................................................................................................................................................................................",0,0,"C");
    $this->Ln(16);
    $this->Cell(300,40," .............................................................................................................................................................................................................................................................................................",0,0,"C");
    
    $this->Ln(16);
    $this->Cell(300,40," .............................................................................................................................................................................................................................................................................................",0,0,"C");
    
    $this->Ln(16);
    $this->Cell(130,40," --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------",0,0,"C");
    
    $this->Ln(70);
    
    $this->Cell(10,40,"Signature :",0,0,"C");

}



function footer() {
    
    //$red = openFile();
    //$et = new Etudiant($_GET['cin']);
    
    $this->Ln();
$this->SetY(-4); 
$this->setFont('Arial','',8); 
$this->Cell(-100,-30,'Developer par MobiSM Societe de developpement et programmation ');
$this->Ln(1);
$this->Cell(10,-15,' Adresse : Monplaisir Tunis Espace Tunis Bloc bureau 5-2 , Email : mongidebbuch7@gmail.com GSM : 0021651110112');

}

function HeaderTable() {
  /*  $this->SetFont('Times','B',12) ; 
    $this->Cell(44,6,'Unite',1,0,'C');
    $this->Cell(23,6,'Coefficient',1,0,'C');
    $this->Cell(15,6,'Credit',1,0,'C');
    $this->Cell(25,6,'Regime',1,0,'C');
    $this->Cell(20,6,'Moyenne',1,0,'C');
    $this->Cell(30,6,'Credit acquis',1,0,'C');
    $this->Cell(126,6,'Element Enseignement',1,0,'C');
    $this->Ln();
*/
/// fetch the  json object 
}

function ViewTable() {
    //$resultasObject = openFile() ; 
    $this->SetFont('Times','',12) ; 
   /* for($counter=0;$counter<count($resultasObject->{'listUnite'});$counter++) {
        $this->Cell(44,10,"".element::getLibelleUniteFromId($resultasObject->{'listUnite'}[$counter]->{"id"}),1,0,'L');
        $this->Cell(21,10," ".$resultasObject->{'listUnite'}[$counter]->{"coef"},1,0,'L');
        $this->Cell(18,10," ".$resultasObject->{'listUnite'}[$counter]->{"creditUnite"},1,0,'L');
        $this->Cell(25,10,"CC",1,0,'L');
        $this->Cell(18,10," ".$resultasObject->{'listUnite'}[$counter]->{"Moyenne_Unite"},1,0,'L');
        $this->Cell(18,10," ".$resultasObject->{'listUnite'}[$counter]->{"creditUnite"},1,0,'L');
        
        for($j=0;$j<count($resultasObject->{'listUnite'}[$counter]->{'listElements'});$j++) {
            $this->Ln();
            $this->Cell(50,10," ",0,0,'L'); 
            $this->Cell(50,10," ",0,0,'L');
            $this->Cell(50,10," ",0,0,'L');
            $this->Cell(60,10," ".Element::getLibelleElementFromID($resultasObject->{'listUnite'}[$counter]->{'listElements'}[$j]->{'idElement'}),1,0,'L'); 
            
            $this->cell(15,10," ".$resultasObject->{'listUnite'}[$counter]->{'listElements'}[$j]->{'moyenne'},1,0,'L' );
            $this->cell(40,10," ".$resultasObject->{'listUnite'}[$counter]->{'listElements'}[$j]->{'credit'} ,1,0,'L');
            
        }
        $this->Ln();
    }*/
    /*
        $this->Cell(55,10,"Libelle",1,0,'L');
        $this->Cell(10,10,"Coef",1,0,'L');
        $this->Cell(15,10,"Regime",1,0,'L');
        $this->Cell(25,10,"Moyenne",1,0,'L');
        $this->Cell(20,10,"Credit aquis",1,0,'L');
        $this->Ln();
        
        
        $this->Cell(44,10,'',0,0,'C');
        $this->Cell(23,10,'',0,0,'C');
        $this->Cell(15,10,'',0,0,'C');
        $this->Cell(25,10,'',0,0,'C');
        $this->Cell(20,10,'',0,0,'C');
        $this->Cell(30,10,'',0,0,'C');
    */
    
}
    
}




    
    $pdf = new MyPDF()   ; 
    
    $pdf->AliasNbPages() ; 
    $pdf->AddPage('P','A4',0) ; 
    $pdf->HeaderTable();
    $pdf->ViewTable();
    $pdf->Output() ;





 



?>