<!DOCTYPE html>
<html lang="en">
<head>
  <title>MobiMed Login </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    function quitter() {
        alert("Au revoir Nawel") ;
        window.location.href="loginNawal.php"; 

    }
    </script>
</head>
<body>
<table class='nawel'><tr><td><img id='nawel' src='nawel.jpg'></td><td> <img width='40px' onclick="quitter()"src='quitetr.png'> </td><tr></table> 
<style>
    img[src='quitetr.png'] {
        margin-left:90%;
        cursor:pointer;
    }
     .nawel {
         background-color:#34495e ; 
        width:100%;
     }
     #nawel {
    box-shadow:20px 20px 30px #ecf0f1;
    width:100px; 
    height:100px;
    border-radius:100px;
}
    </style>
    
<?php 
require "Model.php";
Medecin::getstat();
?>
</body>

    