<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>MobiMed- Reserver Un rendez vous </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!----<a class="navbar-brand" href="mobimed.php">MobiMed</a>---->
  <img src='mobimed.jpg' alt='mobimed' width='40px'>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="Mobimed.php">Acceuil <span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Gestion rendez Vous
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="rdv.php">Ajouter un Rendez Vous</a>
        
               
          </div>
          <!---------------->

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Gestion Patient
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="AjouterPatient.php">Ajouter Un Patient </a>
              
              
            
            </div>

          <!------------------>
      <li class="nav-item">
        <a class="nav-link" href="#">Gestion Comptabilité</a>
      </li>
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="index.html" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Gestion Maladie
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="consultation.php">Ajouter nouvelle Consultation</a>
            <a class="dropdown-item" href="ordanance.php">Gerer Ordonanacement</a>
            <a class="dropdown-item" href="certificatmedicale.php">Gerer Certificat medicale</a>
        </div>
      </li>
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src='avatar.png' width='20px' alt='avatar'><?php echo $_SESSION['user']?>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="#">Ajouter Nouvelle Medecin (En cours ...)</a>
            <a class="dropdown-item" href="#">Ajouter Nouvelle Secretaire (En Cours ...)</a>
            <a class="dropdown-item" href="#">changer photo de profil(En cours ....)</a>
            
          </div>
          
        
    </ul>
  </div>
</nav>
<!----------------------------------->

<label style='color:blue' onclick="window.location.href='mobimed.php'">Acceuil</label>/Ajouter Un Rendez Vous 
<div class="jumbotron text-center">
  <h1>MobiMed</h1>
  <p>Système de gestion de cabinet Medicale </p> 
</div>
  <h3>Reserver Un rendez Vous </h3>
    <form method="POST">
    <table class="table table-darked">
    <tr>
    <td> nombre de Rendez vous : <input type="number" min=0 max=80 name="nb_rdv" class="form-control"></td>
    <td>Cin : <input type="text" class="form-control" size="8" min=0 name="cin_patient"></td>
    <td>Date Rendez Vous (aaa/mm/jj): <input type="text"  size="10" class="form-control" name="Date_rdv"></td>
    <td>heure (heure:minute:second): <input type="text"  class="form-control" name="heure_rdv"></td>
    <td>Nombre de Jours : <input type="text" name="nb_jours" class="form-control"> </td>
    </tr>
    <tr>
    <td>
    <input type="submit" name='BTNEnvoyer' class="btn btn-success" value='Sauvegarder'>
    <input type="reset" name='BTNAnuler' class="btn btn-warning"value='Annuler'>
    </td>
    </tr>
    </table>
    </form>

<?php 
require "Model.php" ; 

if(isset($_POST['BTNEnvoyer']))
RDV::Ajouter($_POST['nb_rdv'],$_POST['Date_rdv'],$_POST['heure_rdv'],$_POST['nb_jours'],$_POST['cin_patient']) 

?>