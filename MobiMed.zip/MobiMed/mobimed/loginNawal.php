<!DOCTYPE html>
<html lang="en">
<head>
  <title>MobiMed Login </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script>

      $(document).ready(function() {
          $(".btn").hide();
      })

function loginMedecin(id) {
    if(id =="Pseudo")
    if($("#"+id).val() =="" || $("#"+id).val().length!=5  || $("#"+id).val() !="Nawel") {
        $("#ErreurLogin").addClass("Erreur");
        document.getElementById('ErreurLogin').innerHTML = "Saisir Valide pseudo SVP ";     
           
    }else 
     {
        $("#ErreurLogin").addClass("Success");

        document.getElementById('ErreurLogin').innerHTML = " Valide Pseudo <img src='ok.png' width='20px'>";     
        
     
     }
     else 
     if(id=="pass")
     if($("#"+id).val() =="" || $("#"+id).val() !="Nawel" )
      {
        $(".btn").hide();
        $("#ErreurPass").addClass("Erreeur");
        document.getElementById('ErreurPass').innerHTML = "Entrer Votre Mot de passe ";  

      }
     else  {
        $("#ErreurPass").addClass("Erreeur");
     document.getElementById('ErreurPass').innerHTML = " Valide Mot de passe <img src='ok.png' width='20px'>";   ;  

     $(".btn").show("1000A");
    }
}
</script>
  <style>
      header {
          background-color:#34495e;
          color:azure;
      }
      footer {
          margin-top:25%;
          background-color:#3498db; 
          color:#ecf0f1;
          box-shadow:20px 20px 30px #ecf0f1;
      }
      .Success {
          background-color:#1abc9c;
      }
      .Erreur {
          background-color :#e74c3c;
      }
  .nawal {
      height:40px;
    background-image: url("nawel.jpg");
      
  }
  body {
       
      background-image : url("images.png");
      background-repeat: no-repeat;
    background-position:99% 50%;

}
label {
    color:#34495e; 
}
    </style>
</head>
<body onload="document.getElementById('cinMedecinLogin').focus()">
<header> <img src='M.jpg'>MobiMed</header>
<form method="POST">
 <table class="table" height="40">
<tr>
    <td><label> Pseudo </label></td><td><input type="text" id='Pseudo' onkeyup="loginMedecin(this.id)"class="form-control" name="cinMedecinLogin"> <p id="ErreurLogin"></p></td>


</tr>
<tr>
    <td><label> Mot de passe </label></td><td><input type="text"  onkeyup="loginMedecin(this.id) "id='pass'class="form-control" name="passMedecinLogin">
    <p id="ErreurPass"></p>
</td>
</tr>
<tr>
    <td colspan="2"><input type="button" name="BTNLoginNawel" onclick='AcceuilNawel()' value="Login" class="btn btn-success"></td>
</tr>
</table>
</form>

</body>

<footer>
    <table class='table'>
    <tr>
<td>    <h5> &copy; 2020 MobiSm </h5></td>
<td> <img src='phone.webp' width='40px'><label> &ensp;00216-51-110-112</label> </td>
<td> <img src='gmail.png' width='40px'><label> &ensp;mdebbich7@gmail.com</label></td>
</tr>
<tr>    
<td><img src='lieu.webp' width='40px'alt='location'> rue 8002, a l'espace de Tunis, Bureau n*2-4 2e étage Mont-plaisir 1073 Tunis</td>

</table>
</footer>
<script>
    function AcceuilNawel() {
window.location.href="AcceuilNawel.php";
}
</script>