<?php 
session_start() ; 

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/MOBIBlue.png" rel="icon">
  <title>Tableau de bord</title>
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <!-- Bootstrap DatePicker -->  
  <link href="vendor/bootstrap-datepicker/css/bootstrap-datepicker.min.css" rel="stylesheet" >
  <link href="css/mobi-admin.min.css" rel="stylesheet">
</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
        <div class="sidebar-brand-icon">
            <img src="img/logo/MOBIBLANC.png" width="100%">
        </div>
        <!--<div class="sidebar-brand-text mx-3"></div>-->
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item ">
        <a class="nav-link" href="index.html">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Tableau de bord</span></a>
      </li>
      <hr class="sidebar-divider">
      <div class="sidebar-heading">
        Menu
      </div>
    
      <li class="nav-item active">
        <a class="nav-link" href="form.php">
          <i class="fab fa-fw fa-wpforms"></i>
          <span>Ajouter patient</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="dataPatient.html">
            <i class="fas fa-table"></i>
          <span>Liste des patients</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="consultation.php">
            <i class="far fa-calendar-plus"></i>
          <span>Ajouter consultation</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="Document.html">
        <i class="fas fa-file"></i>
          <span>Gerer Document</span>
        </a>
      </li>
      

     <!--
      <hr class="sidebar-divider">
      <div class="sidebar-heading">
        Examples
      </div>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePage" aria-expanded="true"
          aria-controls="collapsePage">
          <i class="fas fa-fw fa-columns"></i>
          <span>Pages</span>
        </a>
        <div id="collapsePage" class="collapse" aria-labelledby="headingPage" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Example Pages</h6>
            <a class="collapse-item" href="login.html">Login</a>
            <a class="collapse-item" href="register.html">Register</a>
            <a class="collapse-item" href="404.html">404 Page</a>
            <a class="collapse-item" href="blank.html">Blank Page</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="charts.html">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Charts</span>
        </a>
      </li>-->
      <hr class="sidebar-divider">
      <div class="version" id="version-ruangadmin"></div>
    </ul>
 <!--------------------------------------------------------------------------------------------------------------------------->
    
  
    



    
    
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
          <!-- TopBar -->
          <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
            <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
              <i class="fa fa-bars"></i>
            </button>
            <ul class="navbar-nav ml-auto">
              <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                  aria-haspopup="true" aria-expanded="false">
                  <i class="fas fa-search fa-fw"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                  aria-labelledby="searchDropdown">
                  <form class="navbar-search">
                    <div class="input-group">
                      <input type="text" class="form-control bg-light border-1 small" placeholder="Que voulez-vous rechercher?"
                        aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5;">
                      <div class="input-group-append">
                        <button class="btn btn-primary" type="button">
                          <i class="fas fa-search fa-sm"></i>
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </li>
             
             
              <div class="topbar-divider d-none d-sm-block"></div>
              <li class="nav-item dropdown no-arrow">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                  aria-haspopup="true" aria-expanded="false">
                  <img class="img-profile rounded-circle" src="img/boy.png" style="max-width: 60px">
                  <span class="ml-2 d-none d-lg-inline text-white small"><?php echo $_SESSION['user'];?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                  <a class="dropdown-item" href="#">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    Profil
                  </a>
                  <a class="dropdown-item" href="#">
                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                    Paramètres
                  </a>
                  <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="javascript:void(0);" data-toggle="modal" data-target="#logoutModal">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    Se déconnecter
                  </a>
                </div>
              </li>
            </ul>
          </nav>
          <!-- Topbar -->
  <!-------------------------------------------------------------------------------------------------------------->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
              <h1 class="h3 mb-0 text-gray-800">Ajouter patient</h1>
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Accueil</a></li>
                <li class="breadcrumb-item active" aria-current="page">Ajouter patient</li>
              </ol>
            </div>



             <div class="row">
            <div class="col-lg-12">
              <!-- Ajouter patient -->
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">Ajouter patient</h6>
                </div>
                <div class="card-body">
                  <form method="POST">
                    <div class="form-group">
                      <label for="exampleInput">Numéro de CIN</label>
                      <input type="number"  name="CIN_Patient" class="form-control" id="exampleInput" aria-describedby="emailHelp"
                        placeholder="Numéro de carte d'identité">
                     
                    </div>
                    <div class="form-group">
                        <label for="exampleInput">Nom</label>
                        <input type="text" class="form-control" name="name_patient" id="exampleInput" aria-describedby="emailHelp"
                          placeholder="Nom de la patient">
                       
                      </div>
                      <div class="form-group">
                        <label for="exampleInput">Prénom</label>
                        <input type="text" class="form-control" name="Prenom_patient" id="exampleInput" aria-describedby="emailHelp"
                          placeholder="Prénom de la patient">
                       
                      </div>
                      <div class="form-group" id="simple-date1">
                        <label for="simpleDataInput">Date de naissance</label>
                          <div class="input-group date">
                            <div class="input-group-prepend">
                              <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                            </div>
                            <input type="text" class="form-control"  name='Date_naiss_patient' value="2020/12/30" id="simpleDataInput">
                          </div>
                      </div>
                      <div class="form-group">
                      <table>
                        <tr> <td><label>Sexe</label></td>
  <td>
<input type="radio" name="Sexe" value="M">Masculin 
<input type="radio" name="Sexe" value="F">Femenin
</table></td></tR>
                      </div>

                      <div class="form-group">
                        <label for="exampleFormControlTextarea1">Adresse domicile</label>
                        <textarea class="form-control" name="adresse_patient" id="exampleFormControlTextarea1" rows="3"></textarea>
                      </div>

                      <div class="form-group" id="simple-date1">
                        <label for="simpleDataInput">Code APCI </label>
                          <div class="input-group">
                            <div class="input-group-prepend">
                              <span class="input-group-text"><i class="fas fa-sort-numeric-up-alt">code APCI</i></span>
                            </div>
                            <input type="text" name="Code_APCI" class="form-control" value="12" id="simpleDataInput">
                          </div>
                    </div>
                    
                    <div class="form-group" id="simple-date1">
                        <label for="simpleDataInput">Numéro de téléphone  </label>
                          <div class="input-group">
                            <div class="input-group-prepend">
                              <span class="input-group-text"><i class="fas fa-phone"></i></span>
                            </div>
                            <input type="text" name="num_tel_pat" class="form-control" value="21+" id="simpleDataInput">
                          </div>
                    </div>
                    <?php 
  require "../mobimed/Model.php" ;

if(isset($_POST['BTNEnvoyer'])) {
$date_naissence = explode("/",$_POST['Date_naiss_patient']);
//date in BD : 2020-09-16
// Date in Script : 25-06-1936'
$table = $date_naissence[2]  ."-" . $date_naissence[1] ."-" . $date_naissence[0] ; 
Patient::Ajouter($_SESSION['user'],$_POST['CIN_Patient'],$_POST['name_patient'],$_POST['Prenom_patient'],$table,$_POST['Sexe'],$_POST['adresse_patient'],$_POST['num_tel_pat'],$_POST['Code_APCI']);
echo "<hr>";
}
//$date_rdv , $heure_rdv , $nombre_jours , $num_patient
//DV::Ajouter("Date RDV : 2020-12-30","heure 15:00","periode : 5 jours",1)

?>
</div>
                    <button type="submit" name="BTNEnvoyer" class="btn btn-primary">Ajouter Patient </button>
                  </form>
               
                </div>
            </div>
        </div>
           <!-- Modal Logout -->
           <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelLogout"
           aria-hidden="true">
           <div class="modal-dialog" role="document">
             <div class="modal-content">
               <div class="modal-header">
                 <h5 class="modal-title" id="exampleModalLabelLogout">Ohh non!</h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                   <span aria-hidden="true">&times;</span>
                 </button>
               </div>
               <div class="modal-body">
                 <p>Êtes-vous sûr de vouloir vous déconnecter ?</p>
               </div>
               <div class="modal-footer">
                 <button type="button" class="btn btn-outline-primary" data-dismiss="modal">Annuler</button>
                 <a href="../MobiMed/Deconnecter.php" class="btn btn-primary">Se déconnecter</a>
               </div>
             </div>
           </div>
         </div>

    </div>
    <!-- Footer -->
    <footer class="sticky-footer bg-white">
      <div class="container my-auto">
        <div class="copyright text-center my-auto">
          <span>copyright &copy; <script> document.write(new Date().getFullYear()); </script> - développé par 
            <a href="http://mobi-sm.tn/" target="_blank"><img src="img/logo/mobism.png" height="22px"></a>
          </span>
        </div>
      </div>
    </footer>
    <!-- Footer -->
  </div>
    <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="js/mobi-admin.min.js"></script>
<script src="vendor/chart.js/Chart.min.js"></script>
<script src="js/demo/chart-area-demo.js"></script>  
<!-- Bootstrap Datepicker -->
<script src="vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
<script>
    $(document).ready(function () {
    // Bootstrap Date Picker
    $('#simple-date1 .input-group.date').datepicker({
        format: 'dd/mm/yyyy',
        todayBtn: 'linked',
        todayHighlight: true,
        autoclose: true,
                
      });

    })
</script>
</body>
          
 </html>
