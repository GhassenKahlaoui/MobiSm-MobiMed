<?php 
session_start();
?>
<html>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <!------<a class="navbar-brand" href="mobimed.php">MobiMed</a>----> 
  <img src='mobimed.jpg' alt='mobimed' width='40px'>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="Mobimed.php">Acceuil <span class="sr-only">(current)</span></a>
      </li>
      
      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Gestion rendez Vous
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="rdv.php">Ajouter un Rendez Vous</a>
        
               
          </div>
          <!---------------->

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Gestion Patient
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="AjouterPatient.php">Ajouter Un Patient </a>
              
              
            
            </div>

          <!------------------>
      <li class="nav-item">
        <a class="nav-link" href="#">Gestion Comptabilité</a>
      </li>
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="index.html" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Gestion Maladie
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="consultation.php">Ajouter nouvelle Consultation</a>
            <a class="dropdown-item" href="ordanance.php">Gerer Ordonanacement</a>
            <a class="dropdown-item" href="certificatmedicale.php">Gerer Certificat medicale</a>
        </div>
      </li>
     <!-------------------------------------->

      <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img src='avatar.png' width='20px' alt='avatar'><?php echo $_SESSION['user']?>
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <a class="dropdown-item" href="#">Ajouter Nouvelle Medecin (En cours ...)</a>
            <a class="dropdown-item" href="#">Ajouter Nouvelle Secretaire (En Cours ...)</a>
            <a class="dropdown-item" href="#">changer photo de profil(En cours ....)</a>
            
          </div>
          
    </ul>
  </div>
</nav>
<!----------------------------------->

<label style='color:blue' onclick="window.location.href='mobimed.php'">Acceuil</label>/Ajouter Un Nouvelle Consultation 
<div class="jumbotron text-center">
  <h1>MobiMed</h1>
  <p>Système de gestion de cabinet Medicale </p> 
</div>
<form method="POST">
<table class="table table-darked">
<tr>
    <td> Cin Patient : <input type="text" class="form-control" name="Cin_Patient" size="8"> </td>
    <td> Code Consultation : <input type="text" size="20" class="form-control" name="Code_consltataion"></td>
    <td> Date Consultation (aaaa-mm-jj) : <input type="text" size="14" class="form-control" name="Date_consultation">

</tr>
<tr>
    <td>Diag Consultation : <textarea  name="diag_consoltation" class="form-control"rows="20" cols="50"></textarea></td>
</tr>
<tr>
    <td><button class="btn btn-success" name="BtnEnregistrer">Enregistrer Consultation</button></td>
</tr>
</table>
</form>
</body>
<?php 
require "Model.php" ;
if(isset($_POST["BtnEnregistrer"])) 
Consultation::Ajouter($_POST['Code_consltataion'],$_POST['Date_consultation'],$_POST['diag_consoltation'],$_POST['Cin_Patient']);

?>