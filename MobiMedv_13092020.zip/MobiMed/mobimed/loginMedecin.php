<!DOCTYPE html>
<html lang="en">
<head>
  <title>MobiMed Login </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script>
      $(document).ready(function() {
          $(".btn").hide();
      })

function loginMedecin(id) {
    if(id =="cinMedecinLogin")
    if($("#"+id).val() =="" || $("#"+id).val().length!=8 || isNaN(($("#"+id).val()))) {
        $("#ErreurLogin").addClass("Erreur");
        document.getElementById('ErreurLogin').innerHTML = "Saisir Valide CIN";     
           
    }else 
     {
        $("#ErreurLogin").addClass("Success");

        document.getElementById('ErreurLogin').innerHTML = " Valide CIN";     
        
     
     }
     else 
     if(id=="passMedecinLogin")
     if($("#"+id).val() =="" )
      {
        $(".btn").hide();
        $("#ErreurPass").addClass("Erreeur");
        document.getElementById('ErreurPass').innerHTML = "Entrer Votre Mot de passe ";  

      }
     else  {
     document.getElementById('ErreurPass').innerHTML = "Mot de passe doit contenir Au moins un caractére speciaux";  

     $(".btn").show("1000A");
    }
}
</script>
  <style>
      footer {
          margin-top:25%;
          background-color:#3498db; 
          color:#ecf0f1;
          box-shadow:20px 20px 30px #ecf0f1;
      }
      .Success {
          background-color:#1abc9c;
      }
      .Erreur {
          background-color :#e74c3c;
      }
  body {

      background-image : url("images.png");
      background-repeat: no-repeat;
    background-position:99% 90%;
}
label {
    color:#34495e; 
}


    </style>
</head>
<body onload="document.getElementById('cinMedecinLogin').focus()">
<form method="POST">
    <img src="MobiSM.jpeg">
 <table class="table" height="40">
<tr>
    <td><label> Cin Medecin </label></td><td><input type="text" id='cinMedecinLogin' onkeyup="loginMedecin(this.id)"class="form-control" name="cinMedecinLogin"> <p id="ErreurLogin"></p></td>


</tr>
<tr>
    <td><label> Cin Mot de passe Medecin</label></td><td><input type="text"  onkeyup="loginMedecin(this.id) "id='passMedecinLogin'class="form-control" name="passMedecinLogin">
    <p id="ErreurPass"></p>
</td>
</tr>
<tr>
    <td colspan="2"><input type="submit" name="BTNLoginMedecin" value="Login" class="btn btn-success"></td>
</tr>
</table>
</form>

</body>
<?php
include "Model.php" ; 
if(isset($_POST["BTNLoginMedecin"])) {
if(Medecin::logiMmedecin($_POST["cinMedecinLogin"],$_POST["passMedecinLogin"])==1)

{
    session_start() ; 
    $_SESSION["user"] = $_POST["cinMedecinLogin"];
header("location:AceeuilMedecin.php?user=".$_SESSION['user']);


}
} else 
if(Medecin::logiMmedecin($_POST["cinMedecinLogin"],$_POST["passMedecinLogin"])==-1);

echo "<h4 style='background-color:#e74c3c; color:#ecf0f1;'>Verififé Votre Saisie Si vous avez oublier Mot passe Contatcer l'administrateur </h4>";


?>

<footer>
    <table class='table'>
    <tr>
<td>    <h5> &copy; 2020 MobiSm </h5></td>
<td> <img src='phone.webp' width='40px'><label> &ensp;00216-51-110-112</label> </td>
<td> <img src='gmail.png' width='40px'><label> &ensp;mdebbich7@gmail.com</label></td>
</tr>
<tr>    
<td><img src='lieu.webp' width='40px'alt='location'> rue 8002, a l'espace de Tunis, Bureau n*2-4 2e étage Mont-plaisir 1073 Tunis</td>

</table>
</footer>