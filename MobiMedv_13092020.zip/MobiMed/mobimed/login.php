<html>
<head>
    <meta charset="utf-8">
    <title>Mobimed - login</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  
</head>
<body>
<nav class="nav">
<a href='Acceuil.html'>Acceuil/<a>login
</nav>
<div class="jumbotron text-center">
    <h1>MobiMed</h1>
    <h3>Système de gestion de Cabinet Médicale</h3>
</div>

<section>
    <form method="POST">
  <table class="table">
    <tr>
      <td> <label><img src='user.png' width='20%'> Carte identité Nationale </td>
      <td> <input type='text' name='cin'></td>
</tr>
<tr>
  <td> <label><img src='cle.png' width='10%' > mot de pass</label> </td>
      <td> <input type='text' name='pass'></td>
<tr>
<td>
  <label>Type d'utilisateur</label>
</td>
<td>
</td>
</tr>
<tr>
  <td>
    <input type="submit" value='LogIn' class="btn btn-success" name='BTNEnvoyer'>
</td>
</tr>
</table>
</form>
    <section>
<?php 

require "Model.php" ; 
if(isset($_POST['BTNEnvoyer']) && isset($_POST["type_user"])) 
if($_POST["type_user"] =="Medecin")
{
if(Medecin::logiMmedecin($_POST['cin'],$_POST['pass']==1))
 {
     session_start();
     $_SESSION['user'] = $_POST['cin']; 
     header("location:AceeuilMedecin.php?user=".$_SESSION['user']);
 }
 else 
 echo "<h1 style='background-color:#e74c3c'>Valider Votre Saisie , Si vous avez Oublier Votre Mot de passe Conacter l'administrateur</h1>";
}
else 
if(Admin::LoginAdmin("MobiMed","MobiMed")==1)
 {
   session_start() ; 
   $_SESSION['user'] = "MobiMed" ;
   header("location:mobimed.php?user=".$_Session['user']); 
 }
 
?>


<footer>
  <div class="row">
    <div class="col-md-6">
      <img style='margin-left:20%; padding-top:10%' width='20%' src='mobiSM.png'>
       <table  width='10%' style='margin-left:20%; color:white'>
    
    <tr>

      <td><img src='facebook.webp' width='10%'> 
      <img src='twitter.webp' width='10%'>
      
      <img src='insta.png' width='10%'>
      <img src='linkedIn.png' width='14%'>
    </td>
    </tr>
  </table>
  
    </div>
  
    <div class="col-md-6"><h3>Get In touch</h3>
      <table style=''  class='table '>
        <tr>
    <td>
     <img src='phone.webp' style='color:azure' width='40px'><label style='color:azure'> &ensp;00216-51-110-112</label></td></tr>
    <tr><td><img src='gmail.png'  style='color:azure' width='40px'><label style='color:azure'> &ensp;mdebbich7@gmail.com</label><td><tr>
    </tr>
    <tr>    
    <td style='color:azure'><img src='lieu.webp' width='40px'alt='location'> rue 8002, a l'espace de Tunis, Bureau n*2-4 2e étage Mont-plaisir 1073 Tunis</td>
    </tr>
    <tr>
    
    </tr>
    </table>
    </div>
    
  </div>

<style>
      body {
          background-image: url("images.png");
          
          background-position: 99% 75%;
          background-repeat: no-repeat;

      }
  footer {

  }
table {
  width: 20%;
}
td:nth-child(0),td:nth-child(1),td:nth-child(2) {
  border:0px;
}
footer {
          margin-top:9%;
          background-color:#34495e; 
          color:#ecf0f1;
          box-shadow:20px 20px 30px #ecf0f1;
      }
      footer>table>td {
        color:#ecf0f1;
      }
    nav {
        
        background-color:#34495e; 
        color:azure; 
        padding-left:20px;
            border-top-left-radius:40px;
    }
    nav>a:hover {
        color:#b4c2bf;
    }

    nav>a {
        text-decoration: none;
        color:azure;
    }
</style>
